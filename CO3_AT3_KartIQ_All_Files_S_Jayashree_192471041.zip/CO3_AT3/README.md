# CO3_AT3 — Divide-and-Conquer Engine of KartIQ (Retail Data Analytics Platform)
- **Student Name:** S. Jayashree
- **Register Number:** 192471041
- **Course:** CSA06 – Design and Analysis of Algorithms (CO3 Case Study)

## Contents (All Files Organized in One Folder)
1. `KartIQ_CO3_Case_Study_Report_S_Jayashree_192471041.docx` — Complete Case Study Report (Parts a–f, recurrences, traces, graphs, code, screenshots, final design).
2. `Module1_MergeSort_Pseudocode.txt` & `module1_merge_sort.py` — Stable Merge Sort for Nightly Order Consolidation.
3. `Module2_QuickSort_Pseudocode.txt` & `module2_quick_sort.py` — Hybrid Median-of-Three Quick Sort for Live Seller Leaderboard.
4. `Module3_BinarySearch_Pseudocode.txt` & `module3_binary_search.py` — Leftmost (Lower-Bound) Binary Search for Order Lookup.
5. `Module4_Strassen_Pseudocode.txt` & `module4_strassen.py` — Hybrid Strassen's Matrix Multiplication for Recommendation Scores.
6. `fig1_mergesort.png` to `fig4_strassen.png` — Analytical performance plots.
7. `ss1_mergesort.png` to `ss4_strassen.png` — IDE & execution output screenshots.
8. `m1_mergesort.csv` to `m4_strassen.csv` — Benchmark experimental datasets.
