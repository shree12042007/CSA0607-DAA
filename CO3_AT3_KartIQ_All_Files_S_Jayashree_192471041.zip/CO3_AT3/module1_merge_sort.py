"""
Module 1: Nightly Order Consolidation using Stable Merge Sort
Student: S. Jayashree (192471041) | Course: CSA06 - Design and Analysis of Algorithms
"""
import time, random, math

def merge_sort_orders(orders, trace=False, depth=0):
    if len(orders) <= 1:
        return orders, 0
    mid = len(orders) // 2
    if trace:
        print(f"{'  '*depth}DIVIDE: {orders} -> {orders[:mid]} | {orders[mid:]}")
    left, c_left = merge_sort_orders(orders[:mid], trace, depth + 1)
    right, c_right = merge_sort_orders(orders[mid:], trace, depth + 1)
    merged, c_merge = stable_merge(left, right)
    if trace:
        print(f"{'  '*depth}MERGE : {left} + {right} -> {merged}")
    return merged, c_left + c_right + c_merge

def stable_merge(left, right):
    res, i, j, comps = [], 0, 0, 0
    while i < len(left) and j < len(right):
        comps += 1
        if left[i][0] <= right[j][0]:
            res.append(left[i]); i += 1
        else:
            res.append(right[j]); j += 1
    res.extend(left[i:])
    res.extend(right[j:])
    return res, comps

if __name__ == "__main__":
    sample_orders = [(105, '01'), (102, '02'), (105, '03'), (101, '04'), (102, '05'), (103, '06')]
    print("=== MODULE 1: NIGHTLY ORDER CONSOLIDATION (MERGE SORT) ===")
    sorted_orders, comps = merge_sort_orders(sample_orders, trace=True)
    print(f"\nSorted Output : {sorted_orders}")
    print(f"Comparisons   : {comps}")
    ts_102 = [oid for ts, oid in sorted_orders if ts == 102]
    ts_105 = [oid for ts, oid in sorted_orders if ts == 105]
    assert ts_102 == ['02', '05'] and ts_105 == ['01', '03']
    print(f"Stability Verified: ts=102 -> {ts_102}, ts=105 -> {ts_105}")
