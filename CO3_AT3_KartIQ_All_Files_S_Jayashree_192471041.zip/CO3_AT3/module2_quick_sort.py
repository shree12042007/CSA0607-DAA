"""
Module 2: Live Seller Leaderboard using Median-of-Three + Insertion Hybrid Quick Sort
Student: S. Jayashree (192471041) | Course: CSA06 - Design and Analysis of Algorithms
"""
import time, random

def partition_first_trace(arr):
    a = list(arr)
    pivot = a[0]
    i = 1
    print(f"Initial: {a}, Pivot = {pivot}")
    for j in range(1, len(a)):
        if a[j] < pivot:
            a[i], a[j] = a[j], a[i]
            print(f"  j={j} ({a[i]} < {pivot}): swap -> {a}")
            i += 1
    a[0], a[i - 1] = a[i - 1], a[0]
    print(f"Final pivot swap: {a} (pivot {pivot} at index {i - 1})")
    return a

def quicksort_hybrid_mo3(arr, cutoff=16):
    a = list(arr)
    comps = 0
    def insertion(lo, hi):
        nonlocal comps
        for i in range(lo + 1, hi + 1):
            key = a[i]; j = i - 1
            while j >= lo:
                comps += 1
                if a[j] > key:
                    a[j + 1] = a[j]; j -= 1
                else:
                    break
            a[j + 1] = key

    def qs(lo, hi):
        nonlocal comps
        if hi - lo + 1 <= cutoff:
            if hi > lo: insertion(lo, hi)
            return
        mid = (lo + hi) // 2
        comps += 3
        if a[mid] < a[lo]: a[lo], a[mid] = a[mid], a[lo]
        if a[hi]  < a[lo]: a[lo], a[hi]  = a[hi],  a[lo]
        if a[mid] < a[hi]: a[mid], a[hi] = a[hi],  a[mid]
        pivot = a[hi]
        i = lo
        for j in range(lo, hi):
            comps += 1
            if a[j] <= pivot:
                a[i], a[j] = a[j], a[i]
                i += 1
        a[i], a[hi] = a[hi], a[i]
        qs(lo, i - 1)
        qs(i + 1, hi)

    qs(0, len(a) - 1)
    return a, comps

if __name__ == "__main__":
    scores = [42, 17, 63, 8, 55, 29]
    print("=== MODULE 2: LIVE SELLER LEADERBOARD (QUICK SORT) ===")
    partition_first_trace(scores)
    sorted_scores, c = quicksort_hybrid_mo3(scores, cutoff=4)
    print(f"Fully Sorted Leaderboard: {sorted_scores} (comparisons: {c})")
