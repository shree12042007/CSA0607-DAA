"""
Module 3: First-Occurrence Order Lookup using Modified Binary Search
Student: S. Jayashree (192471041) | Course: CSA06 - Design and Analysis of Algorithms
"""
import math

def binary_search_first_occurrence(orders, target_ts):
    lo, hi = 0, len(orders) - 1
    first_idx = -1
    comps = 0
    while lo <= hi:
        mid = lo + (hi - lo) // 2
        comps += 1
        if orders[mid][0] == target_ts:
            first_idx = mid
            hi = mid - 1
        elif orders[mid][0] < target_ts:
            lo = mid + 1
        else:
            hi = mid - 1
    return first_idx, comps

if __name__ == "__main__":
    consolidated = [(101, '04'), (102, '02'), (102, '05'), (103, '06'), (105, '01'), (105, '03')]
    print("=== MODULE 3: FIRST-OCCURRENCE ORDER LOOKUP (BINARY SEARCH) ===")
    for ts in [102, 105, 104]:
        idx, comps = binary_search_first_occurrence(consolidated, ts)
        rec = consolidated[idx] if idx != -1 else None
        print(f"Target TS={ts} -> First Index={idx}, Record={rec}, Comparisons={comps}")
    n_prod = 10_000_000
    print(f"Production n={n_prod:,} -> Worst-case comparisons = {math.floor(math.log2(n_prod)) + 1}")
