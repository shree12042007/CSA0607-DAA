"""
Module 4: Product Recommendation Scores using Hybrid Strassen's Matrix Multiplication
Student: S. Jayashree (192471041) | Course: CSA06 - Design and Analysis of Algorithms
"""

def mat_add(A, B):
    n = len(A)
    return [[A[i][j] + B[i][j] for j in range(n)] for i in range(n)]

def mat_sub(A, B):
    n = len(A)
    return [[A[i][j] - B[i][j] for j in range(n)] for i in range(n)]

def conventional_multiply(A, B):
    n = len(A)
    C = [[0]*n for _ in range(n)]
    muls = 0
    for i in range(n):
        for k in range(n):
            aik = A[i][k]
            for j in range(n):
                C[i][j] += aik * B[k][j]
                muls += 1
    return C, muls

def strassen_hybrid(A, B, threshold=1):
    n = len(A)
    if n <= threshold:
        return conventional_multiply(A, B)
    mid = n // 2
    A11 = [r[:mid] for r in A[:mid]]; A12 = [r[mid:] for r in A[:mid]]
    A21 = [r[:mid] for r in A[mid:]]; A22 = [r[mid:] for r in A[mid:]]
    B11 = [r[:mid] for r in B[:mid]]; B12 = [r[mid:] for r in B[:mid]]
    B21 = [r[:mid] for r in B[mid:]]; B22 = [r[mid:] for r in B[mid:]]

    M1, c1 = strassen_hybrid(mat_add(A11, A22), mat_add(B11, B22), threshold)
    M2, c2 = strassen_hybrid(mat_add(A21, A22), B11, threshold)
    M3, c3 = strassen_hybrid(A11, mat_sub(B12, B22), threshold)
    M4, c4 = strassen_hybrid(A22, mat_sub(B21, B11), threshold)
    M5, c5 = strassen_hybrid(mat_add(A11, A12), B22, threshold)
    M6, c6 = strassen_hybrid(mat_sub(A21, A11), mat_add(B11, B12), threshold)
    M7, c7 = strassen_hybrid(mat_sub(A12, A22), mat_add(B21, B22), threshold)

    C11 = mat_add(mat_sub(mat_add(M1, M4), M5), M7)
    C12 = mat_add(M3, M5)
    C21 = mat_add(M2, M4)
    C22 = mat_add(mat_sub(mat_add(M1, M3), M2), M6)
    C = [C11[i] + C12[i] for i in range(mid)] + [C21[i] + C22[i] for i in range(mid)]
    return C, c1 + c2 + c3 + c4 + c5 + c6 + c7

if __name__ == "__main__":
    A = [[1, 7], [3, 5]]
    B = [[1, 3], [7, 5]]
    print("=== MODULE 4: RECOMMENDATION MATRIX ENGINE (STRASSEN) ===")
    C_str, m_str = strassen_hybrid(A, B, threshold=1)
    C_std, m_std = conventional_multiply(A, B)
    assert C_str == C_std == [[50, 38], [38, 34]]
    print(f"Sample C = {C_str} | Strassen Muls = {m_str} vs Conventional Muls = {m_std}")
    print(f"Production n=1,024: Conv = {1024**3:,} vs Pure Strassen = {7**10:,} muls")
